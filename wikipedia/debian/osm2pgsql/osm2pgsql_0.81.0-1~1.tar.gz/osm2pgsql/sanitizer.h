#ifndef SANITIZER_H
#define SANITIZER_H

#include <libxml/xmlstring.h>
#include <libxml/xmlreader.h>

xmlTextReaderPtr sanitizerOpen(const char *name);

#endif
