#define NO_MATCH 0
#define FULL_MATCH 1
#define WC_MATCH 2

int wildMatch(char *wildCard, char *string);
