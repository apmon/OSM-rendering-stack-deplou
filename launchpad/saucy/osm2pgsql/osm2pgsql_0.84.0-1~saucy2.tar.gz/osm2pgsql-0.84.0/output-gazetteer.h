#ifndef OUTPUT_GAZETTEER_H
#define OUTPUT_GAZETTEER_H

#include "output.h"

struct output_t out_gazetteer;

#endif
