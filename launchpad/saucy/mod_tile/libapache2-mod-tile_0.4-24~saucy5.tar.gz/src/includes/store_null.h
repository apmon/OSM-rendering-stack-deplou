#ifndef STORE_NULL_H
#define STORE_NULL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "store.h"

   struct storage_backend * init_storage_null();

#ifdef __cplusplus
}
#endif

#endif /* STORE_NULL_H */
