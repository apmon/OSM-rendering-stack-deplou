# TODO

## Roads

turning circles for living streets
turning circles for service
widths for living streets
highway area casing - should be wider
highway area casing and fills should be variables
tunnel casing widths
tunnel fill widths
motorway links are narrower than motorways (fair enough) but nothing else is (fix)
service casing and fill widths
pedestrian widths
residential 10-13 width
highway = road widths
bridge casing widths
paths etc widths
paths etc colours
railway colours
paths etc tunnels
track colours, width and dasharray
track tunnels
bridge casing
bridge colour
lowzoom widths
tram width and colour
guideways width and colour
