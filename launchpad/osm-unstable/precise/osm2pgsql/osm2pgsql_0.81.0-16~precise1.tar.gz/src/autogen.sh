#!/bin/sh
autoreconf -vfi
