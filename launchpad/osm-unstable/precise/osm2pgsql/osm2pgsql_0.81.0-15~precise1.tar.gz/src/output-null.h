/* Implements dummy output-layer processing for testing.
*/
 
#ifndef OUTPUT_NULL_H
#define OUTPUT_NULL_H

#include "output.h"

extern struct output_t out_null;

#endif
