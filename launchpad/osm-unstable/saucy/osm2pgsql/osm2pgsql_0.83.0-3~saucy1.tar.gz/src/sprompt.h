#ifndef SPROMPT_H
#define SPROMPT_H
char *simple_prompt(const char *prompt, int maxlen, int echo);
#endif
